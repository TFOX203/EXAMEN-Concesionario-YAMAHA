import greenfoot.*;

public class Marcador extends Actor {
    public Marcador() {
        actualizarPuntos(0);
    }

    public void actualizarPuntos(int puntos) {
        // texto en blanco, fondo negro con 150 de opacidad (de 0 a 255)
        setImage(new GreenfootImage("Puntos: " + puntos, 30, Color.WHITE, new Color(0, 0, 0, 150)));
    }
}
