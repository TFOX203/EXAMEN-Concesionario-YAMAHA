import greenfoot.*;

public class Apple extends Actor {
    private int velocidad = 3;

    public Apple() {
    }

    public void act() {
        caer();
    }

    private void caer() {
        setLocation(getX(), getY() + velocidad);

        if (getY() >= getWorld().getHeight() - 1) {
            ((MyWorld)getWorld()).perderVida(); // Pierde una vida
            getWorld().removeObject(this); // Quita la manzana
        }
    }
}
