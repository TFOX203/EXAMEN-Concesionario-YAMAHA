import greenfoot.*;

public class Basket extends Actor {
    private int speed = 5;

    

    public void act() {
        mover();
        atrapar();
    }

    private void mover() {
        int x = getX();
        int y = getY();

        if (Greenfoot.isKeyDown("left"))  x -= speed;
        if (Greenfoot.isKeyDown("right")) x += speed;

        // Evita que se salga del mundo
        if (x < 0) x = 0;
        if (x > getWorld().getWidth() - 1) x = getWorld().getWidth() - 1;

        setLocation(x, y);
    }

    private void atrapar() {
        if (isTouching(Apple.class)) {
            removeTouching(Apple.class); // Elimina la manzana
            ((MyWorld)getWorld()).sumarPunto(); // Suma un punto
        }
    }
}
