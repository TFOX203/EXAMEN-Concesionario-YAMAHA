import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class MyWorld extends World
{
    private int score = 0; // Puntos
    private int lives = 3; // Vidas
    private int timer = 0; // Temporizador para crear manzanas 

    public MyWorld()
    {    
        super(600, 400, 1);   // Tamaño del mundo (600x400) 

        // Pone "basket" en el centro 
        addObject(new Basket(), getWidth() / 2, getHeight() - 40);
        
        showText("Puntos: " + score, 70, 20);
        showText("Vidas: " + lives, getWidth() - 70, 20);
    }
    public void act() {
        timer++;
        if (timer % 60 == 0) { 
            int x = Greenfoot.getRandomNumber(getWidth());
            addObject(new Apple(), x, 0);
        }

        showText("Puntos: " + score, 70, 20);
        showText("Vidas: " + lives, getWidth() - 70, 20);

        if (lives <= 0) {
            showText("GAME OVER", getWidth() / 2, getHeight() / 2);
            Greenfoot.stop();
        }
    }

    public void sumarPunto() {
        score++;
    }

    public void perderVida() {
        lives--;
    }
}

