import greenfoot.*;

public class Pelota extends Actor {
    private int velocidad;

    public Pelota() {

        // velocidad aleatoria entre 2 y 6 (puedes ajustar el rango)
        velocidad = Greenfoot.getRandomNumber(5) + 2;
    }

    public void act() {
        caer();
        comprobarColision();
    }

    private void caer() {
        setLocation(getX(), getY() + velocidad);

        if (getY() > getWorld().getHeight() - 1) {
            if (getWorld() instanceof MyWorld) {
                ((MyWorld)getWorld()).gameOver();
            }
            getWorld().removeObject(this);
        }
    }

    private void comprobarColision() {
        Actor canasta = getOneIntersectingObject(Canasta.class);
        if (canasta != null) {
            if (getWorld() instanceof MyWorld) {
                ((MyWorld)getWorld()).sumarPuntos(10);
                ((MyWorld)getWorld()).generarPelota();
            }
            getWorld().removeObject(this);
        }
    }
}
