import greenfoot.*;

public class Mensaje extends Actor {
    private int tiempo = 60; // dura 1 segundo aprox

    public Mensaje(String texto) {
        setImage(new GreenfootImage(texto, 40, Color.YELLOW, new Color(0, 0, 0, 150)));
    }

    public void act() {
        tiempo--;
        if (tiempo <= 0 && getWorld() != null) {
            getWorld().removeObject(this);
        }
    }
}