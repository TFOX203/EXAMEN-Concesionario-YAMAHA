import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Canasta here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Canasta extends Actor
{
    /**
     * Act - do whatever the Canasta wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Canasta() {
        GreenfootImage img = getImage();
        img.scale(100, 100); // ajusta el tamaño
        setImage(img);
    }
    public void act()
    {
        int x = getX();
        int y = getY();
        // Add your action code here.
        if(Greenfoot.isKeyDown("d")){
        x += 12; // derecha
    }
    if(Greenfoot.isKeyDown("a")){
        x -= 12; // izquierda
    }
    setLocation(x, y);
    }
}
