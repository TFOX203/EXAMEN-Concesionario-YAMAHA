import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World{private int puntuacion = 0;
    private Marcador marcador;

    public MyWorld() {
        super(740, 456, 1);

        Canasta canasta = new Canasta();
        addObject(canasta, getWidth() / 2, getHeight() - 50);

        marcador = new Marcador();
        addObject(marcador, getWidth() - 80, 30); // esquina superior derecha
        marcador.actualizarPuntos(puntuacion);

        generarPelota();
    }

    public void generarPelota() {
        int x = Greenfoot.getRandomNumber(getWidth());
        Pelota p = new Pelota();
        addObject(p, x, 0);
    }

    public void sumarPuntos(int puntos) {
        puntuacion += puntos;
        marcador.actualizarPuntos(puntuacion);

        Mensaje msg = new Mensaje("+10");
        addObject(msg, getWidth() / 2, getHeight() / 2);
    }

    public void gameOver() {
        Mensaje msg = new Mensaje("GAME OVER");
        addObject(msg, getWidth() / 2, getHeight() / 2);
        Greenfoot.stop();
    }
}


    

